package cop5555sp15;

public interface Codelet {
	public void execute();
}
